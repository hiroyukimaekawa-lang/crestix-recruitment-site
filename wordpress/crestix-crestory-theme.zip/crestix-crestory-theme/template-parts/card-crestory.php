<?php get_template_part('template-parts/article', 'card'); ?>
